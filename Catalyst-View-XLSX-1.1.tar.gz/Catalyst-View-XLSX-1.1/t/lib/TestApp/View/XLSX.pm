package TestApp::View::XLSX;

use base qw ( Catalyst::View::XLSX );
use strict;
use warnings;

1;
